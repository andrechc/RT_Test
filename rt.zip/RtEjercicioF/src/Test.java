
public class Test {	
	public static void main(String[] args) {
		
		int[] billetesArray = {1, 2, 5, 10, 20, 50, 100};
		
		Caja.generarSobre(new Empleado("Andre", 133399), billetesArray);
		
	}
}
